this is to make the aurdino uno work as the hid device
change the device name in the flash file as per your device name
